from db_helper import get_conn, DB_NAME
from datetime import datetime, timedelta

DB = DB_NAME

def exec_sql(conn, sql, params=None):
    cur = conn.cursor()
    cur.execute(sql, params or ())
    conn.commit()
    cur.close()

def main():
    conn = get_conn(DB)

    # insert instructor and students (INSERT IGNORE style)
    exec_sql(conn, "INSERT IGNORE INTO users (username, full_name, email, role) VALUES (%s,%s,%s,%s)",
             ("inst1", "Prof. A", "inst1@example.com", "instructor"))
    exec_sql(conn, "INSERT IGNORE INTO users (username, full_name, email, role) VALUES (%s,%s,%s,%s)",
             ("stud1", "Student One", "s1@example.com", "student"))
    exec_sql(conn, "INSERT IGNORE INTO users (username, full_name, email, role) VALUES (%s,%s,%s,%s)",
             ("stud2", "Student Two", "s2@example.com", "student"))

    cur = conn.cursor()
    cur.execute("SELECT user_id FROM users WHERE username=%s", ("inst1",))
    inst_row = cur.fetchone()
    if not inst_row:
        print('Instructor insertion failed. Check users table.')
        cur.close(); conn.close(); return
    inst_id = inst_row[0]

    exec_sql(conn, "INSERT IGNORE INTO courses (course_code, title, instructor_id) VALUES (%s,%s,%s)",
             ("CS101", "Intro to DBMS", inst_id))

    cur.execute("SELECT course_id FROM courses WHERE course_code=%s", ("CS101",))
    cid = cur.fetchone()[0]

    cur.execute("SELECT user_id FROM users WHERE username=%s", ("stud1",))
    s1 = cur.fetchone()[0]
    cur.execute("SELECT user_id FROM users WHERE username=%s", ("stud2",))
    s2 = cur.fetchone()[0]

    exec_sql(conn, "INSERT IGNORE INTO enrollments (course_id, student_id) VALUES (%s,%s)", (cid, s1))
    exec_sql(conn, "INSERT IGNORE INTO enrollments (course_id, student_id) VALUES (%s,%s)", (cid, s2))

    due = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
    exec_sql(conn, "INSERT IGNORE INTO assignments (course_id, title, description, due_date) VALUES (%s,%s,%s,%s)",
             (cid, "Assignment 1", "Implement ER diagram and SQL", due))

    cur.close()
    conn.close()
    print('Seeded sample data.')

if __name__ == '__main__':
    main()
