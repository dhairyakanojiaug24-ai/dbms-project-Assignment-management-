import mysql.connector
from mysql.connector import errorcode

# Configure MySQL connection here
CONFIG = {
    'user': 'root',
    'password': '',      # change if you set a root password in XAMPP
    'host': '127.0.0.1',
    'database': None,
    'raise_on_warnings': True
}

DB_NAME = 'assignment_db'

def get_conn(db=None):
    cfg = CONFIG.copy()
    if db:
        cfg['database'] = db
    return mysql.connector.connect(**cfg)

if __name__ == '__main__':
    try:
        conn = get_conn()
        print('Connected to MySQL (no DB specified)')
        conn.close()
    except Exception as e:
        print('Connection test failed:', e)
